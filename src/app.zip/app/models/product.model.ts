export class Product {
    name: string;
    price: number;
    quantitiy: number;
    description: string;
    discount: number;
    category: string;
    // coverImage: string;
    // images: string[];
}
